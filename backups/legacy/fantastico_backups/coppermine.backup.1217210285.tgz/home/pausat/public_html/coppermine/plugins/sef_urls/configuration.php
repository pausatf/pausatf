<?php
/*************************
  Coppermine Photo Gallery
  ************************
  Copyright (c) 2003-2007 Coppermine Dev Team
  v1.1 originally written by Gregory DEMAR

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  ********************************************
  Coppermine version: 1.4.12
  $Source$
  $Revision: 3636 $
  $Author: gaugau $
  $Date: 2007-06-29 11:35:30 +0200 (Fr, 29 Jun 2007) $
**********************************************/

$name = 'Search Engine Friendly URLs';
$description = 'Makes SEF URLs for index, thumbnails, and displayimage.php.<br />Warning: this plugin is still experimental, there are known issues when using it. Test thoroughly and use at your own risk.';
$author = 'Coppermine Development Team';
$version = '1.0';
?>
