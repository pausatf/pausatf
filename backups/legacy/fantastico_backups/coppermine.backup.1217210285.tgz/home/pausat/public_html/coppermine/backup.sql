-- MySQL dump 10.11
--
-- Host: localhost    Database: pausat_copp1
-- ------------------------------------------------------
-- Server version	5.0.51a-community-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cpg_albums`
--

DROP TABLE IF EXISTS `cpg_albums`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cpg_albums` (
  `aid` int(11) NOT NULL auto_increment,
  `title` varchar(255) NOT NULL default '',
  `description` text NOT NULL,
  `visibility` int(11) NOT NULL default '0',
  `uploads` enum('YES','NO') NOT NULL default 'NO',
  `comments` enum('YES','NO') NOT NULL default 'YES',
  `votes` enum('YES','NO') NOT NULL default 'YES',
  `pos` int(11) NOT NULL default '0',
  `category` int(11) NOT NULL default '0',
  `thumb` int(11) NOT NULL default '0',
  `keyword` varchar(50) default NULL,
  `alb_password` varchar(32) default NULL,
  `alb_password_hint` text,
  PRIMARY KEY  (`aid`),
  KEY `alb_category` (`category`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `cpg_albums`
--

LOCK TABLES `cpg_albums` WRITE;
/*!40000 ALTER TABLE `cpg_albums` DISABLE KEYS */;
/*!40000 ALTER TABLE `cpg_albums` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cpg_banned`
--

DROP TABLE IF EXISTS `cpg_banned`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cpg_banned` (
  `ban_id` int(11) NOT NULL auto_increment,
  `user_id` int(11) default NULL,
  `ip_addr` tinytext,
  `expiry` datetime default NULL,
  `brute_force` tinyint(5) NOT NULL default '0',
  PRIMARY KEY  (`ban_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `cpg_banned`
--

LOCK TABLES `cpg_banned` WRITE;
/*!40000 ALTER TABLE `cpg_banned` DISABLE KEYS */;
/*!40000 ALTER TABLE `cpg_banned` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cpg_bridge`
--

DROP TABLE IF EXISTS `cpg_bridge`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cpg_bridge` (
  `name` varchar(40) NOT NULL default '0',
  `value` varchar(255) NOT NULL default '',
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `cpg_bridge`
--

LOCK TABLES `cpg_bridge` WRITE;
/*!40000 ALTER TABLE `cpg_bridge` DISABLE KEYS */;
INSERT INTO `cpg_bridge` VALUES ('short_name',''),('license_number',''),('db_database_name',''),('db_hostname',''),('db_username',''),('db_password',''),('full_forum_url',''),('relative_path_of_forum_from_webroot',''),('relative_path_to_config_file',''),('logout_flag',''),('use_post_based_groups',''),('cookie_prefix',''),('table_prefix',''),('user_table',''),('session_table',''),('group_table',''),('group_relation_table',''),('group_mapping_table',''),('use_standard_groups','1'),('validating_group',''),('guest_group',''),('member_group',''),('admin_group',''),('banned_group',''),('global_moderators_group',''),('recovery_logon_failures','0'),('recovery_logon_timestamp','');
/*!40000 ALTER TABLE `cpg_bridge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cpg_categories`
--

DROP TABLE IF EXISTS `cpg_categories`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cpg_categories` (
  `cid` int(11) NOT NULL auto_increment,
  `owner_id` int(11) NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `description` text NOT NULL,
  `pos` int(11) NOT NULL default '0',
  `parent` int(11) NOT NULL default '0',
  `thumb` int(11) NOT NULL default '0',
  PRIMARY KEY  (`cid`),
  KEY `cat_parent` (`parent`),
  KEY `cat_pos` (`pos`),
  KEY `cat_owner_id` (`owner_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `cpg_categories`
--

LOCK TABLES `cpg_categories` WRITE;
/*!40000 ALTER TABLE `cpg_categories` DISABLE KEYS */;
INSERT INTO `cpg_categories` VALUES (1,0,'User galleries','This category contains albums that belong to Coppermine users.',0,0,0);
/*!40000 ALTER TABLE `cpg_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cpg_comments`
--

DROP TABLE IF EXISTS `cpg_comments`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cpg_comments` (
  `pid` mediumint(10) NOT NULL default '0',
  `msg_id` mediumint(10) NOT NULL auto_increment,
  `msg_author` varchar(25) NOT NULL default '',
  `msg_body` text NOT NULL,
  `msg_date` datetime NOT NULL default '0000-00-00 00:00:00',
  `msg_raw_ip` tinytext,
  `msg_hdr_ip` tinytext,
  `author_md5_id` varchar(32) NOT NULL default '',
  `author_id` int(11) NOT NULL default '0',
  PRIMARY KEY  (`msg_id`),
  KEY `com_pic_id` (`pid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `cpg_comments`
--

LOCK TABLES `cpg_comments` WRITE;
/*!40000 ALTER TABLE `cpg_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `cpg_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cpg_config`
--

DROP TABLE IF EXISTS `cpg_config`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cpg_config` (
  `name` varchar(40) NOT NULL default '',
  `value` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `cpg_config`
--

LOCK TABLES `cpg_config` WRITE;
/*!40000 ALTER TABLE `cpg_config` DISABLE KEYS */;
INSERT INTO `cpg_config` VALUES ('albums_per_page','12'),('album_list_cols','2'),('display_pic_info','0'),('alb_list_thumb_size','50'),('allowed_mov_types','ALL'),('allowed_doc_types','doc/txt/rtf/pdf/xls/pps/ppt/zip/gz/mdb'),('allowed_snd_types','mp3/midi/mid/wma/wav/ogg'),('allowed_img_types','ALL'),('allow_private_albums','1'),('allow_user_registration','0'),('allow_unlogged_access','1'),('allow_duplicate_emails_addr','0'),('caption_in_thumbview','1'),('views_in_thumbview','1'),('charset','utf-8'),('cookie_name','coppermine'),('cookie_path','/'),('debug_mode','0'),('debug_notice','0'),('default_dir_mode','0777'),('default_file_mode','0666'),('default_sort_order','na'),('ecards_more_pic_target','http://pausatf.org/coppermine/'),('home_target','index.php'),('custom_lnk_name',''),('custom_lnk_url',''),('enable_smilies','1'),('filter_bad_words','0'),('forbiden_fname_char','$/\\\\:*?&quot;&#39;&lt;&gt;|` &amp;'),('fullpath','albums/'),('gallery_admin_email','pausat@pausatf.org'),('gallery_description','Photos of the PA/USATF'),('gallery_name','PA/USATF Photo Gallery'),('im_options','-antialias'),('impath','/usr/bin/'),('jpeg_qual','80'),('keep_votes_time','30'),('lang','english'),('main_page_layout','breadcrumb/catlist/alblist/random,2/lastup,2'),('main_table_width','100%'),('make_intermediate','1'),('max_com_lines','10'),('max_com_size','512'),('max_com_wlength','38'),('max_img_desc_length','512'),('max_tabs','12'),('max_upl_size','1024'),('max_upl_width_height','2048'),('auto_resize','0'),('min_votes_for_rating','1'),('normal_pfx','normal_'),('offline','0'),('picture_table_width','600'),('picture_width','400'),('read_exif_data','0'),('reg_requires_valid_email','1'),('subcat_level','2'),('theme','classic'),('thumbcols','4'),('thumbrows','3'),('thumb_method','im'),('thumb_pfx','thumb_'),('thumb_width','100'),('userpics','userpics/'),('vanity_block','1'),('user_profile1_name','Location'),('user_profile2_name','Interests'),('user_profile3_name','Website'),('user_profile4_name','Occupation'),('user_profile5_name',''),('user_profile6_name','Biography'),('user_field1_name',''),('user_field2_name',''),('user_field3_name',''),('user_field4_name',''),('display_comment_count','0'),('show_private','0'),('first_level','1'),('display_film_strip','1'),('display_film_strip_filename','0'),('max_film_strip_items','5'),('thumb_use','any'),('read_iptc_data','0'),('reg_notify_admin_email','0'),('disable_comment_flood_protect','0'),('upl_notify_admin_email','0'),('display_uploader','0'),('display_filename','0'),('language_list','0'),('language_flags','0'),('theme_list','0'),('language_reset','1'),('theme_reset','1'),('allow_memberlist','0'),('display_faq','0'),('show_bbcode_help','1'),('log_ecards','0'),('email_comment_notification','0'),('enable_zipdownload','1'),('slideshow_interval','5000'),('log_mode','0'),('media_autostart','1'),('enable_encrypted_passwords','1'),('time_offset','0'),('ban_private_ip','0'),('smtp_host',''),('smtp_username',''),('smtp_password',''),('enable_plugins','1'),('enable_help','2'),('categories_alpha_sort','0'),('login_threshold','5'),('login_expiry','10'),('allow_email_change','0'),('clickable_keyword_search','1'),('users_can_edit_pics','0'),('show_which_exif','|0|0|0|0|0|0|0|0|1|0|1|1|0|0|0|0|0|0|0|0|0|0|0|1|0|0|0|1|0|0|0|1|1|0|0|0|0|1|0|0|0|1|0|0|1|1|0|0|0|0|0|1|0|1|1'),('alb_desc_thumb','1'),('link_pic_count','0'),('bridge_enable','0'),('language_fallback','1'),('vote_details','0'),('hit_details','0'),('browse_batch_add','1'),('custom_header_path',''),('custom_footer_path',''),('comments_sort_descending','0'),('report_post','0'),('comments_anon_pfx','Guest_'),('admin_activation','0');
/*!40000 ALTER TABLE `cpg_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cpg_dict`
--

DROP TABLE IF EXISTS `cpg_dict`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cpg_dict` (
  `keyId` bigint(20) NOT NULL auto_increment,
  `keyword` varchar(60) NOT NULL default '',
  PRIMARY KEY  (`keyId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `cpg_dict`
--

LOCK TABLES `cpg_dict` WRITE;
/*!40000 ALTER TABLE `cpg_dict` DISABLE KEYS */;
/*!40000 ALTER TABLE `cpg_dict` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cpg_ecards`
--

DROP TABLE IF EXISTS `cpg_ecards`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cpg_ecards` (
  `eid` int(11) NOT NULL auto_increment,
  `sender_name` varchar(50) NOT NULL default '',
  `sender_email` text NOT NULL,
  `recipient_name` varchar(50) NOT NULL default '',
  `recipient_email` text NOT NULL,
  `link` text NOT NULL,
  `date` tinytext NOT NULL,
  `sender_ip` tinytext NOT NULL,
  PRIMARY KEY  (`eid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `cpg_ecards`
--

LOCK TABLES `cpg_ecards` WRITE;
/*!40000 ALTER TABLE `cpg_ecards` DISABLE KEYS */;
/*!40000 ALTER TABLE `cpg_ecards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cpg_exif`
--

DROP TABLE IF EXISTS `cpg_exif`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cpg_exif` (
  `filename` varchar(255) NOT NULL default '',
  `exifData` text NOT NULL,
  UNIQUE KEY `filename` (`filename`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `cpg_exif`
--

LOCK TABLES `cpg_exif` WRITE;
/*!40000 ALTER TABLE `cpg_exif` DISABLE KEYS */;
/*!40000 ALTER TABLE `cpg_exif` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cpg_favpics`
--

DROP TABLE IF EXISTS `cpg_favpics`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cpg_favpics` (
  `user_id` int(11) NOT NULL default '0',
  `user_favpics` text NOT NULL,
  PRIMARY KEY  (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `cpg_favpics`
--

LOCK TABLES `cpg_favpics` WRITE;
/*!40000 ALTER TABLE `cpg_favpics` DISABLE KEYS */;
/*!40000 ALTER TABLE `cpg_favpics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cpg_filetypes`
--

DROP TABLE IF EXISTS `cpg_filetypes`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cpg_filetypes` (
  `extension` varchar(7) NOT NULL default '',
  `mime` varchar(30) default NULL,
  `content` varchar(15) default NULL,
  `player` varchar(5) default NULL,
  PRIMARY KEY  (`extension`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `cpg_filetypes`
--

LOCK TABLES `cpg_filetypes` WRITE;
/*!40000 ALTER TABLE `cpg_filetypes` DISABLE KEYS */;
INSERT INTO `cpg_filetypes` VALUES ('jpg','image/jpg','image',''),('jpeg','image/jpeg','image',''),('jpe','image/jpe','image',''),('gif','image/gif','image',''),('png','image/png','image',''),('bmp','image/bmp','image',''),('jpc','image/jpc','image',''),('jp2','image/jp2','image',''),('jpx','image/jpx','image',''),('jb2','image/jb2','image',''),('swc','image/swc','image',''),('iff','image/iff','image',''),('asf','video/x-ms-asf','movie','WMP'),('asx','video/x-ms-asx','movie','WMP'),('mpg','video/mpeg','movie','WMP'),('mpeg','video/mpeg','movie','WMP'),('wmv','video/x-ms-wmv','movie','WMP'),('swf','application/x-shockwave-flash','movie','SWF'),('avi','video/avi','movie','WMP'),('mov','video/quicktime','movie','QT'),('mp3','audio/mpeg3','audio','WMP'),('midi','audio/midi','audio','WMP'),('mid','audio/midi','audio','WMP'),('wma','audio/x-ms-wma','audio','WMP'),('wav','audio/wav','audio','WMP'),('ogg','audio/ogg','audio',''),('psd','image/psd','image',''),('ram','audio/x-pn-realaudio','document','RMP'),('ra','audio/x-realaudio','document','RMP'),('rm','audio/x-realmedia','document','RMP'),('tiff','image/tiff','document',''),('tif','image/tif','document',''),('doc','application/msword','document',''),('txt','text/plain','document',''),('rtf','text/richtext','document',''),('pdf','application/pdf','document',''),('xls','application/excel','document',''),('pps','application/powerpoint','document',''),('ppt','application/powerpoint','document',''),('zip','application/zip','document',''),('rar','application/rar','document',''),('gz','application/gz','document',''),('mdb','application/msaccess','document','');
/*!40000 ALTER TABLE `cpg_filetypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cpg_hit_stats`
--

DROP TABLE IF EXISTS `cpg_hit_stats`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cpg_hit_stats` (
  `sid` int(11) NOT NULL auto_increment,
  `pid` varchar(100) NOT NULL default '',
  `ip` varchar(20) NOT NULL default '',
  `search_phrase` varchar(255) NOT NULL default '',
  `sdate` bigint(20) NOT NULL default '0',
  `referer` text NOT NULL,
  `browser` varchar(255) NOT NULL default '',
  `os` varchar(50) NOT NULL default '',
  PRIMARY KEY  (`sid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `cpg_hit_stats`
--

LOCK TABLES `cpg_hit_stats` WRITE;
/*!40000 ALTER TABLE `cpg_hit_stats` DISABLE KEYS */;
/*!40000 ALTER TABLE `cpg_hit_stats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cpg_pictures`
--

DROP TABLE IF EXISTS `cpg_pictures`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cpg_pictures` (
  `pid` int(11) NOT NULL auto_increment,
  `aid` int(11) NOT NULL default '0',
  `filepath` varchar(255) NOT NULL default '',
  `filename` varchar(255) NOT NULL default '',
  `filesize` int(11) NOT NULL default '0',
  `total_filesize` int(11) NOT NULL default '0',
  `pwidth` smallint(6) NOT NULL default '0',
  `pheight` smallint(6) NOT NULL default '0',
  `hits` int(10) NOT NULL default '0',
  `mtime` datetime NOT NULL default '0000-00-00 00:00:00',
  `ctime` int(11) NOT NULL default '0',
  `owner_id` int(11) NOT NULL default '0',
  `owner_name` varchar(40) NOT NULL default '',
  `pic_rating` int(11) NOT NULL default '0',
  `votes` int(11) NOT NULL default '0',
  `title` varchar(255) NOT NULL default '',
  `caption` text NOT NULL,
  `keywords` varchar(255) NOT NULL default '',
  `approved` enum('YES','NO') NOT NULL default 'NO',
  `galleryicon` int(11) NOT NULL default '0',
  `user1` varchar(255) NOT NULL default '',
  `user2` varchar(255) NOT NULL default '',
  `user3` varchar(255) NOT NULL default '',
  `user4` varchar(255) NOT NULL default '',
  `url_prefix` tinyint(4) NOT NULL default '0',
  `pic_raw_ip` tinytext,
  `pic_hdr_ip` tinytext,
  `lasthit_ip` tinytext,
  `position` int(11) NOT NULL default '0',
  PRIMARY KEY  (`pid`),
  KEY `owner_id` (`owner_id`),
  KEY `pic_hits` (`hits`),
  KEY `pic_rate` (`pic_rating`),
  KEY `aid_approved` (`aid`,`approved`),
  KEY `pic_aid` (`aid`),
  FULLTEXT KEY `search` (`title`,`caption`,`keywords`,`filename`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `cpg_pictures`
--

LOCK TABLES `cpg_pictures` WRITE;
/*!40000 ALTER TABLE `cpg_pictures` DISABLE KEYS */;
/*!40000 ALTER TABLE `cpg_pictures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cpg_plugins`
--

DROP TABLE IF EXISTS `cpg_plugins`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cpg_plugins` (
  `plugin_id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(64) NOT NULL default '',
  `path` varchar(128) NOT NULL default '',
  `priority` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`plugin_id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `path` (`path`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `cpg_plugins`
--

LOCK TABLES `cpg_plugins` WRITE;
/*!40000 ALTER TABLE `cpg_plugins` DISABLE KEYS */;
/*!40000 ALTER TABLE `cpg_plugins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cpg_sessions`
--

DROP TABLE IF EXISTS `cpg_sessions`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cpg_sessions` (
  `session_id` varchar(40) NOT NULL default '',
  `user_id` int(11) default '0',
  `time` int(11) default NULL,
  `remember` int(1) default '0',
  PRIMARY KEY  (`session_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `cpg_sessions`
--

LOCK TABLES `cpg_sessions` WRITE;
/*!40000 ALTER TABLE `cpg_sessions` DISABLE KEYS */;
INSERT INTO `cpg_sessions` VALUES ('479cd6df1b60e1d234f31546efde4057',0,1190921950,0);
/*!40000 ALTER TABLE `cpg_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cpg_temp_data`
--

DROP TABLE IF EXISTS `cpg_temp_data`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cpg_temp_data` (
  `unique_ID` varchar(8) NOT NULL default '',
  `encoded_string` blob NOT NULL,
  `timestamp` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`unique_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `cpg_temp_data`
--

LOCK TABLES `cpg_temp_data` WRITE;
/*!40000 ALTER TABLE `cpg_temp_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `cpg_temp_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cpg_usergroups`
--

DROP TABLE IF EXISTS `cpg_usergroups`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cpg_usergroups` (
  `group_id` int(11) NOT NULL auto_increment,
  `group_name` varchar(255) NOT NULL default '',
  `group_quota` int(11) NOT NULL default '0',
  `has_admin_access` tinyint(4) NOT NULL default '0',
  `can_rate_pictures` tinyint(4) NOT NULL default '0',
  `can_send_ecards` tinyint(4) NOT NULL default '0',
  `can_post_comments` tinyint(4) NOT NULL default '0',
  `can_upload_pictures` tinyint(4) NOT NULL default '0',
  `can_create_albums` tinyint(4) NOT NULL default '0',
  `pub_upl_need_approval` tinyint(4) NOT NULL default '1',
  `priv_upl_need_approval` tinyint(4) NOT NULL default '1',
  `upload_form_config` tinyint(4) NOT NULL default '3',
  `custom_user_upload` tinyint(4) NOT NULL default '0',
  `num_file_upload` tinyint(4) NOT NULL default '5',
  `num_URI_upload` tinyint(4) NOT NULL default '3',
  PRIMARY KEY  (`group_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `cpg_usergroups`
--

LOCK TABLES `cpg_usergroups` WRITE;
/*!40000 ALTER TABLE `cpg_usergroups` DISABLE KEYS */;
INSERT INTO `cpg_usergroups` VALUES (1,'Administrators',0,1,1,1,1,1,1,0,0,3,0,5,3),(2,'Registered',1024,0,1,1,1,1,1,1,0,3,0,5,3),(3,'Anonymous',0,0,1,0,0,0,0,1,1,0,0,5,3),(4,'Banned',0,0,0,0,0,0,0,1,1,0,0,5,3);
/*!40000 ALTER TABLE `cpg_usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cpg_users`
--

DROP TABLE IF EXISTS `cpg_users`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cpg_users` (
  `user_id` int(11) NOT NULL auto_increment,
  `user_group` int(11) NOT NULL default '2',
  `user_active` enum('YES','NO') NOT NULL default 'NO',
  `user_name` varchar(25) NOT NULL default '',
  `user_password` varchar(40) NOT NULL default '',
  `user_lastvisit` datetime NOT NULL default '0000-00-00 00:00:00',
  `user_regdate` datetime NOT NULL default '0000-00-00 00:00:00',
  `user_group_list` varchar(255) NOT NULL default '',
  `user_email` varchar(255) NOT NULL default '',
  `user_profile1` varchar(255) NOT NULL default '',
  `user_profile2` varchar(255) NOT NULL default '',
  `user_profile3` varchar(255) NOT NULL default '',
  `user_profile4` varchar(255) NOT NULL default '',
  `user_profile5` varchar(255) NOT NULL default '',
  `user_profile6` text NOT NULL,
  `user_actkey` varchar(32) NOT NULL default '',
  PRIMARY KEY  (`user_id`),
  UNIQUE KEY `user_name` (`user_name`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `cpg_users`
--

LOCK TABLES `cpg_users` WRITE;
/*!40000 ALTER TABLE `cpg_users` DISABLE KEYS */;
INSERT INTO `cpg_users` VALUES (1,1,'YES','pausat','8271fe232582c6492a659518c45dc4b0','2007-09-26 12:36:56','2007-09-26 12:36:20','','pausat@pausatf.org','','','','','','','');
/*!40000 ALTER TABLE `cpg_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cpg_vote_stats`
--

DROP TABLE IF EXISTS `cpg_vote_stats`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cpg_vote_stats` (
  `sid` int(11) NOT NULL auto_increment,
  `pid` varchar(100) NOT NULL default '',
  `rating` smallint(6) NOT NULL default '0',
  `ip` varchar(20) NOT NULL default '',
  `sdate` bigint(20) NOT NULL default '0',
  `referer` text NOT NULL,
  `browser` varchar(255) NOT NULL default '',
  `os` varchar(50) NOT NULL default '',
  PRIMARY KEY  (`sid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `cpg_vote_stats`
--

LOCK TABLES `cpg_vote_stats` WRITE;
/*!40000 ALTER TABLE `cpg_vote_stats` DISABLE KEYS */;
/*!40000 ALTER TABLE `cpg_vote_stats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cpg_votes`
--

DROP TABLE IF EXISTS `cpg_votes`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cpg_votes` (
  `pic_id` mediumint(9) NOT NULL default '0',
  `user_md5_id` varchar(32) NOT NULL default '',
  `vote_time` int(11) NOT NULL default '0',
  PRIMARY KEY  (`pic_id`,`user_md5_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `cpg_votes`
--

LOCK TABLES `cpg_votes` WRITE;
/*!40000 ALTER TABLE `cpg_votes` DISABLE KEYS */;
/*!40000 ALTER TABLE `cpg_votes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2008-07-28  1:58:05
