<?php

    define ( 'SILLY_SAFE_MODE' , 1 ) ;

    $CONFIG['dbserver'] = 'localhost' ;
    $CONFIG['dbuser'  ] = 'pausat_copp1' ;
    $CONFIG['dbpass'  ] = 'tXxmPgoHTyCM' ;
    $CONFIG['dbname'  ] = 'pausat_copp1'   ;

    $CONFIG['TABLE_PREFIX'] = 'cpg_' ;

?>
